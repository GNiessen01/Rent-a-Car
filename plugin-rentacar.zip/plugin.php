<?php
/**
 * Plugin Name: Rent-a-Car-Search
 * Description: Search filter for bookings
 */

function rentacar_search_function() {
    $content = "This is a plugin";

    $content .="<div>This is a div</div>";
    $content .="<p>This is a paragraph text.</p>";

    return $content;
}
add_shortcode('shortcode_plugin_search','rentacar_search_function');
?>

<input type="text" id="txtFrom" name="Fromdate">
<input type="submit" id="search" name="Search">

<?php
$hostname="localhost";
$dbname="giovanni_wp353";
$username="giovanni";
$password="verkering2020";

$conn=mysqli_connect("$hostname","$username","$password","$dbname");

if(isset($_POST)Search) {
    $selcttxt=$_POST(Fromdate);
    $query=mysqli_query($conn,"select * from " );
}




?>

